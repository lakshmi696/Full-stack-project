<?php

require_once('db.php');

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$password = $_POST['password'];


$checkEmailQuery = "SELECT * FROM user WHERE email = '$email'";
$checkEmailResult = mysqli_query($conn, $checkEmailQuery);
if (mysqli_num_rows($checkEmailResult) > 0) {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Email already exists. Please choose a different email.');
    window.location.href='../ureg.php';
    </SCRIPT>");
    exit();
}

$sql = "INSERT INTO user (`firstname`, `lastname`, `email`, `phone`, `gender`, `password`) VALUES ('$firstname', '$lastname', '$email', '$phone', '$gender', '$password')";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Successfully Added');
    window.location.href='../admin.php';
    </SCRIPT>");
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
