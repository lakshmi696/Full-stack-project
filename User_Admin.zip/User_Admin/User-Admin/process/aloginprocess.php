<?php

require_once ('db.php');

$userid = $_POST['uid'];
$password = $_POST['pwd'];

$sql = "SELECT * from `admin` WHERE userid = '$userid' AND password = '$password'";


$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) == 1){
	
	header("Location:../admin.php?");
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Credentials')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

mysqli_close($conn);
?>
