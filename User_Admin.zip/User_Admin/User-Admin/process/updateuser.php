<?php
require_once('db.php');

$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profilepic']) && $_FILES['profilepic']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['profilepic'];
    $filename = $file['name'];
    $tmpFilePath = $file['tmp_name'];
    $uploadDir = 'images/';
    $uploadPath = $uploadDir . $filename;
    
    if (move_uploaded_file($tmpFilePath, $uploadPath)) {
        $sql = "UPDATE user SET `firstname` = '$firstname', `lastname` = '$lastname', `gender` = '$gender', `phone` = '$phone', `profile` = '$filename' WHERE `id` = $id";
    }
} else {
    $sql = "UPDATE user SET `firstname` = '$firstname', `lastname` = '$lastname', `gender` = '$gender', `phone` = '$phone' WHERE `id` = $id";
}

$result = mysqli_query($conn, $sql);

if ($result) {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('User details updated successfully')
        window.location.href='../admin.php';
        </SCRIPT>");
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Failed to update user details')
        window.location.href='edit.php?id=$id';
        </SCRIPT>");
}

mysqli_close($conn);
?>
