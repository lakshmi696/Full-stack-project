<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "edgroom";

$conn = mysqli_connect($server, $username, $password, $dbname);

if(!$conn){
	echo "Databese Connection Failed";
}

?>