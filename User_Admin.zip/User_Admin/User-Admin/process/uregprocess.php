<?php

require_once('db.php');

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$password = $_POST['password'];

$checkEmailQuery = "SELECT * FROM user WHERE email = '$email'";
$checkEmailResult = mysqli_query($conn, $checkEmailQuery);

if (mysqli_num_rows($checkEmailResult) > 0) {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Email already exists. Please choose a different email.');
    window.location.href='../ureg.php';
    </SCRIPT>");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profilepic']) && $_FILES['profilepic']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['profilepic'];
    $filename = $file['name'];
    $tmpFilePath = $file['tmp_name'];
    $uploadDir = 'images/';
    $uploadPath = $uploadDir . $filename;
    
    if (move_uploaded_file($tmpFilePath, $uploadPath)) {
        $sql = "INSERT INTO user (`firstname`, `lastname`, `email`, `phone`, `gender`, `password`, `profile`) VALUES ('$firstname', '$lastname', '$email', '$phone', '$gender', '$password', '$filename')";
        
        if (mysqli_query($conn, $sql)) {
            $to = $email;
            $subject = "Registration Successful";
            $message = "Dear $firstname,\n\nCongratulations! You have successfully registered.\n\nThank you for joining us.";
            $headers = "From: vinaykumarpragada24@gmail.com"; 
        
            mail($to, $subject, $message, $headers);
        
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Successfully Registered');
            window.location.href='../ulogin.php';
            </SCRIPT>");
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error uploading the file.";
    }
} else {
    echo "Invalid form submission or file upload error.";
}

mysqli_close($conn);
?>
