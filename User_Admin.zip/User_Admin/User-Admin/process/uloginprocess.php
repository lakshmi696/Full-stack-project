<?php
session_start();
require_once('db.php');

if (isset($_POST['mail']) && isset($_POST['pwd'])) {
    $email = $_POST['mail'];
    $password = $_POST['pwd'];

    $sql = "SELECT * FROM `user` WHERE `email` = '$email' AND `password` = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['email'] = $email;
        header("Location: ../user.php");
        exit();
    } else {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invalid Credentials');
        window.location.href='../ulogin.php';
        </SCRIPT>");
    }
} else {
    echo 'Email and password are required.';
}

mysqli_close($conn);
?>
