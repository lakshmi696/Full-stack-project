<?php
require_once('process/db.php');

$sql = "SELECT CONCAT(firstname,' ',lastname)as fullname,gender,phone,email,`profile`,id FROM user";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

    <title>Admin</title>
    <style>
        .navbar-nav .nav-link {
            color: white;
        }
        body {
            background-color: #5D6D7E;
        }
        thead th {
            background-color: #ADD8E6;
            color: black;
        }
        .container{
          margin-top:30px;
        }

        table.dataTable th,
        table.dataTable td {
          border: 1px solid black;
          text-align: center;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.html">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="adduser.php">Add User</a>
        </li>
      </ul>
      <form class="form-inline ml-auto" role="search" action="search.php" method="POST">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
        <button class="btn btn-outline-success my-2 my-sm-0" name="save" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

<div class="container">
    <table id="userTable" class="dataTable">
        <thead>
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Profile</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['fullname']; ?></td>
                    <td><?php echo $row['gender']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><img src="process/images/<?php echo $row['profile']; ?>" alt="Profile Image" width="100" height="100"></td>
                    <td><a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> | <a href="delete.php?id=<?php echo $row['id']; ?>" onClick="return confirm('Are you sure you want to delete?')">Delete</a></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $('#userTable').DataTable();
    });
</script>
</body>
</html>
