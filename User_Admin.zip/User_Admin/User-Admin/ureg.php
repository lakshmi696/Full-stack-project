<!DOCTYPE html>
<html>
<head>
	<title>Register | User</title>
    <style>
    
        body {

            background-color: #5D6D7E;
            background-size: cover;
            background-position: center;
            font-family: sans-serif;
        }

        .registerbox {
            width: 550px;
            height: 600px;
            background: #000;
            color: #fff;
            top: 50%;
            left: 50%;
            position: absolute;
            transform: translate(-50%,-50%);
            box-sizing: border-box;
            padding: 30px 30px;
            text-align: center;
            border-radius: 30px;
        }

        .registerbox h1 {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .registerbox input[type="text"],
        .registerbox input[type="email"],
        .registerbox input[type="tel"],
        .registerbox input[type="gender"],
        .registerbox input[type="password"] {
            border: none;
            border-bottom: 1px solid #fff;
            background: transparent;
            outline: none;
            color: white;
            height: 40px;
            width: 300px;
            font-size: 16px;
            margin-bottom: 15px;
        }

        .registerbox input[type="submit"] {
            border: none;
            outline: none;
            height: 40px;
            color: #fff;
            font-size: 16px;
            background: #5D6D7E;
            cursor: pointer;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .registerbox a {
            color: #5D6D7E;
            text-decoration: none;
        }
        .gender{
            position: relative;
            left:-50px;
        }

        .profile h5{
            position:relative;
            left:-113px;
        }

        .registerbox input[type="file"] {
            position: relative;
            left:100px;
            top:-40px;

        }

    </style>
</head>
<body>
	<div class="registerbox">
        <h1><u>REGISTER</u></h1>
        <form id="registrationform" action="process/uregprocess.php" method="POST" enctype="multipart/form-data">
            
            <input type="text" name="firstname" placeholder="First Name" required="required" minlength="3"><br>
            <input type="text" name="lastname" placeholder="Last Name" required="required" minlength="3"><br>
            <div class="gender">
            <label for="gender-male">
                <input type="radio" name="gender" id="gender-male" value="Male" required="required">
                Male
            </label>
            <label for="gender-female">
                <input type="radio" name="gender" id="gender-female" value="Female" required="required">
                Female
            </label>
            <label for="gender-other">
                <input type="radio" name="gender" id="gender-other" value="other" required="required">
                Other
            </label>
            </div><br>
            <input type="email" name="email" placeholder="Email" required="required" pattern="^[A-Za-z0-9._%+-]+@[^.]+\bcom$"><br>
            <input type="tel" name="phone" placeholder="Phone Number" required="required" pattern="[0-9]{10,}"><br>
            <input type="password" name="password" placeholder="Password" required="required" required pattern="^(?=.*\d)(?=.*[a-zA-Z])(?=.*\W).{8,}$">
            <br>
            <div class="profile">
            <h5>Profile Photo</h5>
            <input type="file" name="profilepic" id="profilepic" accept="image/*" required="required">
            </div>

            <input type="submit" name="register-submit" value="Register">

            <p>Already have an account? <a href="ulogin.php">Log In Here</a></p>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#registrationForm').submit(function(e) {
                e.preventDefault();
                if (validateForm()) {
                    this.submit();
                }
            });
        });

        function validateForm() {
            var isValid = true;
            var errorContainer = $('#errorContainer');
            errorContainer.html('');

            var firstname = $('#firstname').val();
            if (firstname.length < 3) {
                displayError('First name must be at least 3 characters');
                isValid = false;
            }

            var lastname = $('#lastname').val();
            if (lastname.length < 3) {
                displayError('Last name must be at least 3 characters');
                isValid = false;
            }

            var email = $('#email').val();
            if (!email.match(^[A-Za-z0-9._%+-]+@[^.]+\bcom$)) {
                displayError('Mail should end with @gmail.com');
                isValid = false;
            }

            var phone = $('#phone').val();
            if (!phone.match([0-9]{10,}/)) {
                displayError('Please enter 10 digit phone number');
                isValid = false;
            }

            var password = $('#password').val();
            if (!password.match(/^(?=.*\d)(?=.*[a-zA-Z])(?=.*\W).{8,}$/)) {
                displayError('Password must be at least 8 characters and contain at least one capital letter, one number, and one special character');
                isValid = false;
            }

            var profilepic = $('#profilepic').prop('files')[0];
            if (profilepic && profilepic.size > (2 * 1024 * 1024)) {
                displayError('Profile picture size should be less than 2MB');
                isValid = false;
            }

            return isValid;
        }

        function displayError(message) {
            var errorContainer = $('#errorContainer');
            errorContainer.append('<p>' + message + '</p>');
        }

        function validateFileSize(input) {
            var file = input.files[0];
            if (file && file.size > (2 * 1024 * 1024)) {
                input.value = '';
                displayError('Profile picture size should be less than 2MB');
            }
        }
    </script>
</body>
</html>
