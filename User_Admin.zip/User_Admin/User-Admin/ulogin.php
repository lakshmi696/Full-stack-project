<!DOCTYPE html>
<html>
<head>
	<title>Log In | User</title>
    <style>
    
        body {
	        margin: 0;
	        padding: 0;
            background-color: #5D6D7E;
            background-size: cover;
            background-position: center;
            font-family: sans-serif;
        }

        .loginbox {
            width: 450px;
            height: 450px;
            background: #000;
            color: #fff;
            top: 50%;
            left: 50%;
            position: absolute;
            transform: translate(-50%,-50%);
            box-sizing: border-box;
            padding: 60px 30px;
            text-align: center;
            border-radius: 30px;
        }

        .loginbox h1 {
            font-size: 24px;
            margin-bottom: 30px;
        }

        .loginbox input[type="text"],
        .loginbox input[type="password"] {
            border: none;
            border-bottom: 1px solid #fff;
            background: transparent;
            outline: none;
            height: 40px;
            color: #fff;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .loginbox input[type="submit"] {
            border: none;
            outline: none;
            height: 40px;
            color: #fff;
            font-size: 16px;
            background: #5D6D7E;
            cursor: pointer;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .loginbox a {
            color: #5D6D7E;
            text-decoration: none;
        }

    </style>
</head>
<body>
	<div class="loginbox">
        <h1><u>LOGIN</u></h1>
        <form action="process/uloginprocess.php" method="POST">
            <input type="text" name="mail" placeholder="Enter Email" required="required"><br>
            <input type="password" name="pwd" placeholder="Enter Password" required="required">
            <br><br>
            <input type="submit" name="login-submit" value="Login">

            <p>Don't Have An Account? <a href="ureg.php">Register Here</a></p>
        </form>
    </div>
</body>
</html>
