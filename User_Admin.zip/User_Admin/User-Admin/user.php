  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
      <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

      <title>User</title>
      <style>
          .navbar-nav .nav-link {
              color: white;
          }
          body {
              background-color: #5D6D7E;
          }
          thead th {
              background-color: #ADD8E6;
              color: black;
          }
          .container{
            margin-top:30px;
          }
          table.dataTable th,
          table.dataTable td {
            border: 1px solid black;
            text-align: center;
          }
      </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="home.html">Home</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">
      <table id="userTable" class="dataTable">
          <thead>
              <tr>
                  <th>Name</th>
                  <th>Gender</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Profile</th>
                  <th>Update</th>
              </tr>
          </thead>
          <?php 
          session_start();
          require_once('process/db.php');
          
          if (isset($_SESSION['email'])) {
              $email = $_SESSION['email'];
          }
          
          $sql = "SELECT * FROM `user` WHERE `email` = '$email'";
          $result = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($result)) { ?>
                  <tr>
                      <td><?php echo $row['firstname']; ?></td>
                      <td><?php echo $row['gender']; ?></td>
                      <td><?php echo $row['phone']; ?></td>
                      <td><?php echo $row['email']; ?></td>
                      <td><img src="process/images/<?php echo $row['profile']; ?>" alt="Profile Image" width="100" height="100"></td> 
                      <td><a href="edit2.php?id=<?php echo $row['id']; ?>">Edit</a></td>
                  </tr>
              <?php } ?>
      </table>
  </div>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  </body>
  </html>
